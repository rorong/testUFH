$(document).ready(function() {
  $("#FeaturedMenus").on("click", function() {
    $("#FeaturedMenusContent").animate({scrollTop: "+=500px"}, 800);
  });
});
