$(".alert" ).fadeOut(3000);
